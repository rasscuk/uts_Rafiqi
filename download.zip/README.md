# Pasar Online - Web Marketplace (PHP Native + MySQLi + Bootstrap)

1. Buat database MySQL, impor `database.sql`.
2. Salin `config/koneksi.example.php` menjadi `config/koneksi.php`, lalu isi kredensial dan hash password admin.
3. Upload semua file ke `htdocs`. Admin: `/admin/login.php`.

`config/koneksi.php` masuk `.gitignore` agar kredensial tidak ikut ke GitHub.
