<?php require 'auth.php';
$id = (int)($_GET['id'] ?? 0);
$p = ['nama_produk'=>'','deskripsi'=>'','harga'=>'','stok'=>'','id_kategori'=>'','id_penjual'=>'','gambar'=>''];
if ($id) {
  $st = $conn->prepare("SELECT * FROM produk WHERE id_produk=?"); $st->bind_param('i', $id); $st->execute();
  $p = $st->get_result()->fetch_assoc();
  if (!$p) { exit('Produk tidak ditemukan'); }
}
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama = trim($_POST['nama_produk']); $desk = trim($_POST['deskripsi']); $harga = (float)$_POST['harga'];
  $stok = (int)$_POST['stok']; $kat = (int)$_POST['id_kategori']; $pen = (int)$_POST['id_penjual']; $gambar = $p['gambar'];
  if ($nama === '' || $harga <= 0 || $stok < 0) { $err = 'Nama, harga (>0), dan stok (>=0) wajib valid.'; }
  if (!$err && !empty($_FILES['gambar']['name'])) {
    $ext = strtolower(pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp']) || $_FILES['gambar']['size'] > 2*1024*1024) { $err = 'Gambar harus JPG/PNG/WEBP maks 2MB.'; }
    else { $gambar = uniqid('p_') . '.' . $ext; move_uploaded_file($_FILES['gambar']['tmp_name'], __DIR__ . '/../uploads/' . $gambar); }
  }
  if (!$err) {
    if ($id) {
      $st = $conn->prepare("UPDATE produk SET nama_produk=?,deskripsi=?,harga=?,stok=?,id_kategori=?,id_penjual=?,gambar=? WHERE id_produk=?");
      $st->bind_param('ssdiiisi', $nama, $desk, $harga, $stok, $kat, $pen, $gambar, $id);
    } else {
      $st = $conn->prepare("INSERT INTO produk (nama_produk,deskripsi,harga,stok,id_kategori,id_penjual,gambar) VALUES (?,?,?,?,?,?,?)");
      $st->bind_param('ssdiiis', $nama, $desk, $harga, $stok, $kat, $pen, $gambar);
    }
    $st->execute(); header('Location: produk.php'); exit;
  }
}
$kats = $conn->query("SELECT * FROM kategori"); $pens = $conn->query("SELECT * FROM penjual");
$base = '../'; include __DIR__ . '/../includes/header.php'; ?>
<h3><?= $id ? 'Edit' : 'Tambah' ?> Produk</h3>
<?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="row g-3 bg-white p-3 rounded shadow-sm">
  <div class="col-12"><label class="form-label">Nama Produk</label><input name="nama_produk" class="form-control" value="<?= e($p['nama_produk']) ?>" required></div>
  <div class="col-md-6"><label class="form-label">Kategori</label><select name="id_kategori" class="form-select">
    <?php while ($k = $kats->fetch_assoc()): ?><option value="<?= $k['id_kategori'] ?>" <?= $k['id_kategori']==$p['id_kategori']?'selected':'' ?>><?= e($k['nama_kategori']) ?></option><?php endwhile; ?></select></div>
  <div class="col-md-6"><label class="form-label">Penjual</label><select name="id_penjual" class="form-select">
    <?php while ($s = $pens->fetch_assoc()): ?><option value="<?= $s['id_penjual'] ?>" <?= $s['id_penjual']==$p['id_penjual']?'selected':'' ?>><?= e($s['nama_toko']) ?></option><?php endwhile; ?></select></div>
  <div class="col-md-6"><label class="form-label">Harga</label><input type="number" step="100" name="harga" class="form-control" value="<?= e($p['harga']) ?>" required></div>
  <div class="col-md-6"><label class="form-label">Stok</label><input type="number" name="stok" class="form-control" value="<?= e($p['stok']) ?>" required></div>
  <div class="col-12"><label class="form-label">Deskripsi</label><textarea name="deskripsi" rows="3" class="form-control"><?= e($p['deskripsi']) ?></textarea></div>
  <div class="col-12"><label class="form-label">Gambar</label><input type="file" name="gambar" class="form-control"></div>
  <div class="col-12"><button class="btn btn-success">Simpan</button> <a href="produk.php" class="btn btn-outline-secondary">Batal</a></div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
