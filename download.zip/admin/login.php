<?php require __DIR__ . '/../config/koneksi.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (($_POST['user'] ?? '') === $admin_user && password_verify($_POST['pass'] ?? '', $admin_hash)) {
    $_SESSION['admin'] = true; header('Location: produk.php'); exit;
  }
  $err = 'Username atau password salah.';
}
$base = '../'; include __DIR__ . '/../includes/header.php'; ?>
<div class="row justify-content-center"><div class="col-md-4">
<h3>Login Admin</h3>
<?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="bg-white p-3 rounded shadow-sm">
  <input name="user" class="form-control mb-2" placeholder="Username" required>
  <input type="password" name="pass" class="form-control mb-3" placeholder="Password" required>
  <button class="btn btn-success w-100">Masuk</button>
</form></div></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
