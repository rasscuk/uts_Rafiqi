<?php require 'auth.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = (int)$_POST['id'];
  try { $st = $conn->prepare("DELETE FROM produk WHERE id_produk=?"); $st->bind_param('i', $id); $st->execute(); }
  catch (mysqli_sql_exception $ex) { exit('Produk tidak bisa dihapus karena sudah ada di riwayat pesanan. <a href="produk.php">Kembali</a>'); }
}
header('Location: produk.php');
