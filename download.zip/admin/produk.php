<?php require 'auth.php'; $base = '../'; include __DIR__ . '/../includes/header.php';
$res = $conn->query("SELECT p.*, k.nama_kategori FROM produk p JOIN kategori k ON p.id_kategori=k.id_kategori ORDER BY p.id_produk DESC"); ?>
<div class="d-flex justify-content-between mb-3"><h3>Kelola Produk</h3>
  <div><a href="produk_form.php" class="btn btn-success">+ Tambah Produk</a> <a href="logout.php" class="btn btn-outline-secondary">Logout</a></div></div>
<table class="table bg-white align-middle"><thead><tr><th>#</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th></th></tr></thead><tbody>
<?php while ($r = $res->fetch_assoc()): ?>
<tr><td><?= $r['id_produk'] ?></td><td><?= e($r['nama_produk']) ?></td><td><?= e($r['nama_kategori']) ?></td><td><?= rupiah($r['harga']) ?></td><td><?= $r['stok'] ?></td>
<td><a href="produk_form.php?id=<?= $r['id_produk'] ?>" class="btn btn-sm btn-warning">Edit</a>
<form method="post" action="produk_hapus.php" class="d-inline" onsubmit="return confirm('Hapus produk ini?')">
<input type="hidden" name="id" value="<?= $r['id_produk'] ?>"><button class="btn btn-sm btn-danger">Hapus</button></form></td></tr>
<?php endwhile; ?></tbody></table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
