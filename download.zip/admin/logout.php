<?php require __DIR__ . '/../config/koneksi.php'; unset($_SESSION['admin']); header('Location: login.php');
