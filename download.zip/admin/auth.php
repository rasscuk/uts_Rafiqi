<?php
require __DIR__ . '/../config/koneksi.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
