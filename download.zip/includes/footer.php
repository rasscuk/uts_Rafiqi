</div>
<footer class="f"><div class="container text-center">&copy; <?= date('Y') ?> pasarku &middot; Marketplace Tradisional Bengkulu</div></footer>
</body></html>
