<?php require_once __DIR__ . '/helper.php'; $base = $base ?? '';
$jml = array_sum($_SESSION['cart'] ?? []); $flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); ?>
<!doctype html>
<html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pasar Online - Belanja Produk Tradisional</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= $base ?>assets/style.css" rel="stylesheet">
</head><body>
<div class="topmini d-none d-md-block"><div class="container d-flex justify-content-between">
  <span>Gratis ongkir untuk belanja tertentu &middot; Langsung dari penjual pasar Bengkulu</span>
  <a href="<?= $base ?>admin/produk.php" class="text-decoration-none">Mulai Berjualan (Admin)</a></div></div>
<div class="topbar"><div class="container d-flex align-items-center gap-3">
  <a class="brand" href="<?= $base ?>index.php">pasarku</a>
  <form class="search" action="<?= $base ?>index.php" method="get">
    <input name="q" placeholder="Cari produk di pasarku" value="<?= e($_GET['q'] ?? '') ?>"><button>Cari</button></form>
  <a class="navlink" href="<?= $base ?>keranjang.php">🛒 Keranjang<?php if ($jml): ?><span class="cartbadge"><?= $jml ?></span><?php endif; ?></a>
</div></div>
<?php if ($flash): ?><div class="toast-n"><?= e($flash) ?></div><?php endif; ?>
<div class="container py-4">
