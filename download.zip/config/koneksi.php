<?php
// File ini berisi kredensial. JANGAN di-upload ke GitHub (sudah ada di .gitignore).
$db_host = 'sql303.infinityfree.com';
$db_user = 'if0_42986988';
$db_pass = 'Sidosen2026Umb';
$db_name = 'if0_42986988_andri_marketplace';

// Login admin: username admin, password Admin2026
$admin_user = 'admin';
$admin_hash = '$2y$10$4xVd3pd1jhXhwlgiFo1aS.WY5KAWNAmVfx4sHhFOWdvevVXxUyoy6';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
  $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name, 3306);
} catch (mysqli_sql_exception $ex) { die('Koneksi database gagal.'); }
mysqli_set_charset($conn, 'utf8mb4');
session_start();
function rupiah($n) { return 'Rp ' . number_format($n, 0, ',', '.'); }
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
