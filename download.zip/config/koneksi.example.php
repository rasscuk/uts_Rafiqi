<?php
// Salin file ini menjadi koneksi.php lalu isi kredensial. JANGAN commit koneksi.php.
$db_host = 'sqlXXX.infinityfree.com';
$db_user = 'if0_XXXXXXXX';
$db_pass = 'ISI_PASSWORD';
$db_name = 'if0_XXXXXXXX_marketplace';

// Akun admin. Buat hash dengan: php -r "echo password_hash('passwordanda', PASSWORD_DEFAULT);"
$admin_user = 'admin';
$admin_hash = 'ISI_HASH_PASSWORD';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
  $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
} catch (mysqli_sql_exception $ex) { die('Koneksi database gagal.'); }
mysqli_set_charset($conn, 'utf8mb4');
session_start();
function rupiah($n) { return 'Rp ' . number_format($n, 0, ',', '.'); }
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
