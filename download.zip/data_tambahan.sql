INSERT INTO kategori (nama_kategori) VALUES ('Rempah & Bumbu'),('Batik & Kain');
INSERT INTO penjual (nama_toko, telepon, alamat) VALUES ('Kios Bu Sari','082211223344','Pasar Panorama, Bengkulu'),('Batik Besurek Pak Rudi','085266778899','Jl. Fatmawati, Bengkulu');
INSERT INTO produk (id_penjual,id_kategori,nama_produk,deskripsi,harga,stok) VALUES
(2,1,'Sayur Bayam Segar 1 Ikat','Bayam hijau segar dipetik pagi hari.',5000,80),
(2,1,'Jeruk Kalamansi 1 Kg','Jeruk kecil segar, cocok untuk sambal dan minuman.',18000,40),
(2,4,'Cabai Rawit Merah 250g','Cabai rawit pedas segar langsung dari petani.',15000,25),
(2,4,'Kunyit Bubuk Asli 100g','Kunyit giling murni tanpa campuran.',12000,8),
(1,3,'Pendap Bengkulu 5 Pcs','Makanan khas Bengkulu berbahan ikan dan daun talas.',35000,20),
(1,3,'Lempuk Durian 250g','Dodol durian khas Bengkulu.',28000,12),
(1,2,'Tas Anyaman Pandan','Tas anyaman pandan buatan pengrajin lokal.',65000,9),
(3,5,'Kain Batik Besurek 2 Meter','Batik khas Bengkulu motif kaligrafi Besurek.',185000,10),
(3,5,'Selendang Batik Besurek','Selendang batik tulis motif Rafflesia.',95000,15);
